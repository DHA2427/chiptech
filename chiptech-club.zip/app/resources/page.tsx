import Link from "next/link"
import { ArrowRight, BookOpen, Download, ExternalLink, FileText, Video } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ResourcesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Learning Resources
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-200 md:text-xl">
                Access tutorials, guides, and learning materials to enhance your skills in robotics, embedded systems,
                and hardware development.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="tutorials" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
                <TabsTrigger value="guides">Guides</TabsTrigger>
                <TabsTrigger value="tools">Tools & Software</TabsTrigger>
                <TabsTrigger value="courses">Recommended Courses</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="tutorials" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <Video className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Video Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">Getting Started with Arduino</CardTitle>
                    <CardDescription>
                      Learn the basics of Arduino programming and build your first circuit.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This tutorial covers Arduino IDE setup, basic programming concepts, and a step-by-step guide to
                      building a simple LED circuit.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Beginner</div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">30 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/arduino-basics" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <FileText className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Written Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">Introduction to Raspberry Pi</CardTitle>
                    <CardDescription>
                      Set up your Raspberry Pi and learn how to use it for various projects.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This guide walks you through the initial setup of Raspberry Pi, installing the operating system,
                      and basic Linux commands for beginners.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Beginner</div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">45 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/raspberry-pi-intro" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <Video className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Video Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">PCB Design Fundamentals</CardTitle>
                    <CardDescription>Learn how to design printed circuit boards using KiCad.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This tutorial covers schematic capture, component placement, routing, and design rule checking for
                      creating professional PCBs.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs text-yellow-800">
                        Intermediate
                      </div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">60 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/pcb-design" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <FileText className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Written Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">Sensors and Actuators</CardTitle>
                    <CardDescription>
                      Comprehensive guide to different types of sensors and actuators used in robotics.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Learn about various sensors (temperature, proximity, light, etc.) and actuators (motors, servos,
                      solenoids) with practical examples and circuit diagrams.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Beginner</div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">50 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/sensors-actuators" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <Video className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Video Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">Building a Robot Chassis</CardTitle>
                    <CardDescription>Step-by-step guide to designing and building a robot chassis.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This tutorial covers material selection, design considerations, assembly techniques, and motor
                      mounting for building a sturdy robot chassis.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs text-yellow-800">
                        Intermediate
                      </div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">90 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/robot-chassis" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <FileText className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Written Tutorial</div>
                    </div>
                    <CardTitle className="mt-4">IoT Communication Protocols</CardTitle>
                    <CardDescription>
                      Overview of common communication protocols used in IoT applications.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This guide explains various protocols like MQTT, HTTP, CoAP, and Zigbee, with examples of when to
                      use each and how to implement them in your projects.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs text-yellow-800">
                        Intermediate
                      </div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">40 min</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/iot-protocols" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Tutorial
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="guides" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <BookOpen className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Comprehensive Guide</div>
                    </div>
                    <CardTitle className="mt-4">Robotics Project Planning</CardTitle>
                    <CardDescription>
                      A complete guide to planning and executing robotics projects from concept to completion.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This guide covers project scoping, component selection, budgeting, timeline planning, and testing
                      methodologies for successful robotics projects.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/robotics-planning" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Guide
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <BookOpen className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Comprehensive Guide</div>
                    </div>
                    <CardTitle className="mt-4">Embedded Systems Architecture</CardTitle>
                    <CardDescription>
                      Understanding the fundamentals of embedded systems design and architecture.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This guide explains microcontroller selection, memory considerations, peripheral interfaces, and
                      real-time operating systems for embedded applications.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/embedded-architecture" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Guide
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className="rounded-full bg-blue-100 p-2">
                        <BookOpen className="h-4 w-4 text-blue-700" />
                      </div>
                      <div className="text-sm text-gray-500">Comprehensive Guide</div>
                    </div>
                    <CardTitle className="mt-4">IoT System Design</CardTitle>
                    <CardDescription>
                      End-to-end guide for designing Internet of Things systems and applications.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This guide covers sensor selection, connectivity options, cloud platforms, data storage,
                      visualization, and security considerations for IoT projects.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/resources/iot-design" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Guide
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="tools" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Arduino IDE</CardTitle>
                    <CardDescription>Integrated development environment for Arduino programming.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      The official Arduino IDE for writing, compiling, and uploading code to Arduino boards. Includes
                      libraries and examples for beginners.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.arduino.cc/en/software"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>KiCad</CardTitle>
                    <CardDescription>Open-source electronics design automation suite.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Professional tool for schematic capture and PCB layout with a 3D viewer. Supports multi-sheet
                      schematics and complex board designs.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.kicad.org/download/"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Fusion 360</CardTitle>
                    <CardDescription>3D CAD, CAM, and CAE software for product design.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Powerful design tool for creating 3D models of mechanical parts, robot chassis, and enclosures.
                      Free for students and educational use.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.autodesk.com/products/fusion-360/education"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Visual Studio Code</CardTitle>
                    <CardDescription>Lightweight but powerful source code editor.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Popular code editor with extensions for Arduino, Python, and other languages used in robotics and
                      embedded systems development.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://code.visualstudio.com/download"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Fritzing</CardTitle>
                    <CardDescription>Electronics documentation and PCB design tool.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      User-friendly tool for creating circuit diagrams, breadboard layouts, and PCB designs. Great for
                      documenting and sharing electronics projects.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://fritzing.org/download/"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Node-RED</CardTitle>
                    <CardDescription>Flow-based programming tool for IoT applications.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Visual tool for wiring together hardware devices, APIs, and online services for creating IoT
                      applications with minimal coding.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://nodered.org/docs/getting-started/"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        Download
                        <Download className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="courses" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Introduction to Robotics</CardTitle>
                    <CardDescription>Comprehensive course covering robotics fundamentals.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This course covers robot kinematics, dynamics, control systems, sensors, actuators, and
                      programming. Suitable for beginners with basic programming knowledge.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Beginner</div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">8 weeks</div>
                      <div className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs text-green-800">Free</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.edx.org/course/introduction-to-robotics"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        View Course
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Embedded Systems Programming</CardTitle>
                    <CardDescription>
                      Learn to program microcontrollers and develop embedded applications.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This course covers C/C++ programming for microcontrollers, memory management, interrupts,
                      real-time operating systems, and interfacing with sensors and peripherals.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs text-yellow-800">
                        Intermediate
                      </div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">10 weeks</div>
                      <div className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs text-green-800">Free</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.coursera.org/learn/embedded-systems"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        View Course
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>IoT Fundamentals</CardTitle>
                    <CardDescription>Comprehensive introduction to Internet of Things technologies.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This course covers IoT architecture, protocols, cloud platforms, data analytics, and security
                      considerations for building connected devices and systems.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Beginner</div>
                      <div className="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-800">6 weeks</div>
                      <div className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs text-green-800">Free</div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link
                      href="https://www.futurelearn.com/courses/iot-fundamentals"
                      className="w-full"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full">
                        View Course
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Request Resources Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Can't Find What You Need?</h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                If you're looking for specific resources or have suggestions for new tutorials, let us know.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/resources/request">
                <Button className="bg-blue-600 hover:bg-blue-700">Request Resources</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Join Our Community</h2>
              <p className="max-w-[600px] text-gray-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Become a member of ChipTech Club to access exclusive resources and participate in hands-on workshops.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/join">
                <Button className="bg-white text-blue-700 hover:bg-gray-100">
                  Join the Club
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

