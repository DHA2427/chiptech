import Link from "next/link"
import { ArrowRight, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"

export default function JoinPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Join ChipTech Club
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-200 md:text-xl">
                Become a part of RV University's premier tech community and explore the world of robotics and hardware
                innovations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Membership Benefits Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-800">
                Membership Benefits
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Why Join ChipTech Club?</h2>
              <ul className="grid gap-2">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Access to specialized workshops and training sessions</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Opportunity to work on real-world projects and competitions</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Networking with industry professionals and like-minded peers</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Access to club resources, equipment, and lab facilities</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Mentorship from senior students and faculty advisors</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Certificate of participation and skill development</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-blue-600" />
                  <span>Priority registration for club events and workshops</span>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-800">
                Membership Plans
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Choose Your Plan</h2>
              <div className="grid gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Basic Membership</CardTitle>
                    <CardDescription>
                      For students who want to explore the world of hardware and robotics.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">
                      ₹500<span className="text-sm font-normal text-gray-500">/year</span>
                    </div>
                    <ul className="mt-4 grid gap-2">
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Access to general meetings and events</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Basic workshop participation</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Club newsletter and updates</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                <Card className="border-blue-600">
                  <CardHeader className="bg-blue-50">
                    <div className="flex items-center justify-between">
                      <CardTitle>Premium Membership</CardTitle>
                      <div className="rounded-full bg-blue-600 px-2 py-1 text-xs text-white">Popular</div>
                    </div>
                    <CardDescription>
                      For dedicated students who want to fully immerse in tech projects.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">
                      ₹1000<span className="text-sm font-normal text-gray-500">/year</span>
                    </div>
                    <ul className="mt-4 grid gap-2">
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>All Basic Membership benefits</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Priority access to advanced workshops</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Exclusive access to lab equipment</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>Project funding opportunities</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-blue-600" />
                        <span>One-on-one mentorship sessions</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Application Form Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Apply for Membership</h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Fill out the form below to apply for ChipTech Club membership.
              </p>
            </div>
          </div>
          <div className="mx-auto max-w-2xl space-y-6 mt-8">
            <form className="space-y-6">
              <div className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="first-name">First Name</Label>
                    <Input id="first-name" placeholder="Enter your first name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="last-name">Last Name</Label>
                    <Input id="last-name" placeholder="Enter your last name" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" placeholder="Enter your email" type="email" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-id">Student ID</Label>
                  <Input id="student-id" placeholder="Enter your student ID" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="course">Course & Year</Label>
                  <Input id="course" placeholder="e.g., B.Tech Computer Science, 2nd Year" required />
                </div>
                <div className="space-y-2">
                  <Label>Membership Type</Label>
                  <RadioGroup defaultValue="basic">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="basic" id="basic" />
                      <Label htmlFor="basic">Basic Membership (₹500/year)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="premium" id="premium" />
                      <Label htmlFor="premium">Premium Membership (₹1000/year)</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="experience">Technical Experience</Label>
                  <Textarea
                    id="experience"
                    placeholder="Briefly describe your experience with robotics, programming, or hardware projects"
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="interests">Areas of Interest</Label>
                  <Textarea
                    id="interests"
                    placeholder="What specific areas of robotics, embedded systems, or hardware are you interested in?"
                    rows={4}
                  />
                </div>
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Submit Application
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Frequently Asked Questions</h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Find answers to common questions about ChipTech Club membership.
              </p>
            </div>
          </div>
          <div className="mx-auto max-w-3xl space-y-4 mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Do I need prior experience to join?</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  No, we welcome members of all skill levels. Our basic workshops are designed to help beginners get
                  started, while more advanced sessions cater to experienced members.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>How much time commitment is expected?</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  The time commitment varies based on your level of involvement. General meetings are held bi-weekly,
                  and workshops typically run for 2-3 hours. Project work may require additional time based on your role
                  and the project scope.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Can I switch between membership plans?</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Yes, you can upgrade from Basic to Premium membership at any time by paying the difference. Downgrades
                  are processed at the time of renewal.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Are there any additional costs beyond the membership fee?</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  The membership fee covers most club activities and basic materials. Some advanced workshops or special
                  projects may have additional material costs, but these are always communicated in advance and are
                  typically optional.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>How do I renew my membership?</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Membership renewals are processed at the beginning of each academic year. You'll receive a renewal
                  notification via email with instructions on how to complete the process.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Still Have Questions?</h2>
              <p className="max-w-[600px] text-gray-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Contact us directly and we'll be happy to assist you with any inquiries about joining ChipTech Club.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/contact">
                <Button className="bg-white text-blue-700 hover:bg-gray-100">Contact Us</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

