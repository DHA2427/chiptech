import Link from "next/link"
import Image from "next/image"
import { Calendar, ChevronRight, MapPin, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function EventsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-cyan-900/20 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white font-['Space_Grotesk']">
                Events & Activities
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-300 md:text-xl font-['Outfit']">
                Join our workshops, hackathons, and tech talks to enhance your skills and connect with like-minded
                individuals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400 font-['Outfit']">
                Event Highlights
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Recent Activities
              </h2>
              <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                A glimpse into our recent workshops, events, and projects.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="relative h-80 overflow-hidden rounded-lg">
                <Image src="/images/ribbon-cutting.png" alt="Inauguration ceremony" fill className="object-cover" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">Centre Inauguration</h3>
                <p className="text-gray-400 font-['Outfit']">
                  The official inauguration of the Centre for IoT & Edge Computing at RV University, marking the
                  beginning of our journey.
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="relative h-80 overflow-hidden rounded-lg">
                <Image
                  src="/images/auditorium.png"
                  alt="Technical seminar in auditorium"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">Technical Seminar</h3>
                <p className="text-gray-400 font-['Outfit']">
                  A technical seminar on emerging trends in IoT and Edge Computing, attended by students and faculty
                  from across the university.
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="relative h-80 overflow-hidden rounded-lg">
                <Image
                  src="/images/water-level-project.png"
                  alt="Water level detector project"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">IoT Project Showcase</h3>
                <p className="text-gray-400 font-['Outfit']">
                  Students demonstrating their water level detector project, an example of practical IoT applications
                  developed at the club.
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="relative h-80 overflow-hidden rounded-lg">
                <Image src="/images/group-photo-1.png" alt="Workshop group photo" fill className="object-cover" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">Hands-on Workshop</h3>
                <p className="text-gray-400 font-['Outfit']">
                  A collaborative workshop where students and faculty worked together on innovative IoT solutions for
                  real-world problems.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-900">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="upcoming" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-gray-800">
                <TabsTrigger
                  value="upcoming"
                  className="data-[state=active]:bg-cyan-900 data-[state=active]:text-white font-['Outfit']"
                >
                  Upcoming Events
                </TabsTrigger>
                <TabsTrigger
                  value="past"
                  className="data-[state=active]:bg-cyan-900 data-[state=active]:text-white font-['Outfit']"
                >
                  Past Events
                </TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="upcoming" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">Ideathon</CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Brainstorm innovative solutions for real-world IoT and Edge Computing challenges.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>
                          Status: <span className="text-cyan-400">Loading...</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Tech Lab, Engineering Building</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>Limited to 30 participants</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/ideathon" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        Register Now
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">Roboquest</CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Robotics competition to build and program autonomous robots for specific challenges.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>
                          Status: <span className="text-cyan-400">Processing...</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Innovation Center</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>Teams of 3-5 members</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/roboquest" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        Register Now
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">Circutrix</CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Circuit design competition focusing on innovative embedded systems solutions.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>
                          Status: <span className="text-cyan-400">Deploying...</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Auditorium, Main Campus</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>Open to all students</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/circutrix" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        Register Now
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="past" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">Introduction to Raspberry Pi</CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Hands-on session with Raspberry Pi for beginners.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>March 5, 2025</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Computer Lab, Engineering Building</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>35 participants attended</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/raspberry-pi-intro" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        View Details
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">IoT Project Showcase</CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Exhibition of student-built Internet of Things projects.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>February 20, 2025</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Main Hall, Student Center</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>15 projects showcased</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/iot-showcase" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        View Details
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card className="bg-gray-900 border-gray-800 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-white font-['Space_Grotesk']">
                      Tech Talk: Future of Edge Computing
                    </CardTitle>
                    <CardDescription className="text-gray-400 font-['Outfit']">
                      Panel discussion with industry experts on edge computing trends.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Calendar className="h-4 w-4 text-cyan-400" />
                        <span>January 15, 2025</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <MapPin className="h-4 w-4 text-cyan-400" />
                        <span>Auditorium, Main Campus</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                        <Users className="h-4 w-4 text-cyan-400" />
                        <span>120+ attendees</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Link href="/events/edge-computing-talk" className="w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                      >
                        View Details
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Future Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400 font-['Outfit']">
                Looking Ahead
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Future Events Planned
              </h2>
              <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                Our upcoming initiatives to foster learning and innovation.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 mt-8">
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white font-['Space_Grotesk']">Student Internships</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 font-['Outfit']">
                  The Centre for Distributed Computing aims to have tie-ups with Industry and Hospitals in and around
                  Bengaluru. Through these, we aim to provide summer internships to our undergraduate students in
                  industry or within the center.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/internships" className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Learn More
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white font-['Space_Grotesk']">Guest Lectures</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 font-['Outfit']">
                  Industry Experts will deliver guest lectures to our undergraduate students & research scholars on
                  upcoming, relevant topics. A few topics have also been identified for immediate delivery.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/events/guest-lectures" className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Learn More
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-cyan-900/20 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Propose an Event
              </h2>
              <p className="max-w-[600px] text-gray-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                Have an idea for a workshop, hackathon, or tech talk? We welcome event proposals from our members.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/events/propose">
                <Button className="bg-cyan-600 text-white hover:bg-cyan-700 font-['Outfit']">Submit Proposal</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

