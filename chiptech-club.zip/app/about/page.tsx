import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-cyan-900/20 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white">
                About ChipTech
              </h1>
              <p className="font-['Outfit'] mx-auto max-w-[700px] text-gray-300 md:text-xl">
                Building the future of technology through innovation, collaboration, and hands-on learning.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400">Our Mission</div>
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Centre for IoT & Edge Computing
              </h2>
              <p className="font-['Outfit'] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                The ChipTech Club operates as the Centre for IoT & Edge Computing at RV University, focusing on
                cutting-edge research and practical applications in the field of IoT and Edge Computing.
              </p>
              <p className="font-['Outfit'] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We aim to bridge the gap between theoretical knowledge and practical applications by providing hands-on
                experience, mentorship, and resources to our members while conducting research in specialized areas.
              </p>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full h-[310px] rounded-xl overflow-hidden">
                <Image
                  alt="ChipTech Club Team Working on a Project"
                  src="/images/group-photo-2.png"
                  fill
                  className="object-cover object-center"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Research Areas Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Key Research Areas
              </h2>
              <p className="font-['Outfit'] max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                The specialized research areas that drive our innovation and projects.
              </p>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Edge Computing</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  AI in Edge Computing, Edge resource management, and Distributed Computing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Research on computational offloading, edge resource management, and applying AI techniques to optimize
                  edge computing systems.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">SPOC:</span> Prof. Chandramouleeswaran Sankaran
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">IoT in Healthcare</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  Application of Edge solutions on Healthcare and Assistive Technologies
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Developing IoT solutions for healthcare monitoring, diagnostics, and assistive technologies to improve
                  patient care and accessibility.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">SPOC:</span> Dr. Vidya M J
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Image Processing</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  Advanced image processing techniques for IoT and edge applications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Research on efficient image processing algorithms that can run on resource-constrained edge devices
                  for real-time applications.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">SPOC:</span> Prof. CVSN Reddy
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Assistive Technologies</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  Developing technology solutions to assist people with disabilities
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Creating innovative hardware and software solutions that improve accessibility and quality of life for
                  people with various disabilities.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">SPOC:</span> Dr. Mydhili K Nair
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Computational Offloading</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  Optimizing resource usage in distributed computing environments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Research on efficient task distribution and computational offloading strategies for edge-cloud
                  environments to optimize performance and energy usage.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">SPOC:</span> Prof. Veena S
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Industrial IoT</CardTitle>
                <CardDescription className="font-['Outfit'] text-gray-400">
                  IoT applications for industrial automation and monitoring
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-sm text-gray-400">
                  Developing IoT solutions for industrial settings, including smart manufacturing, predictive
                  maintenance, and industrial automation.
                </p>
                <p className="font-['Outfit'] text-sm text-gray-400 mt-2">
                  <span className="text-cyan-400 font-semibold">Area Track:</span> Device level Automation
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Our Team
              </h2>
              <p className="font-['Outfit'] max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                The dedicated faculty and industry experts behind ChipTech's success.
              </p>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="font-['Space_Grotesk'] text-xl font-bold text-white mb-4">Single Point Of Contact</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-cyan-950/50 p-3">
                    <Users className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-white">Prof. Chandramouleeswaran Sankaran</CardTitle>
                    <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                      Professor, School of Computer Science and Engineering, RVU
                    </CardDescription>
                    <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">chandramouleeswarans@rvu.edu.in</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-cyan-950/50 p-3">
                    <Users className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-white">Dr. Vidya M J</CardTitle>
                    <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                      Assistant Professor, School of Computer Science and Engineering, RVU
                    </CardDescription>
                    <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">vidyam@rvu.edu.in</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <h3 className="font-['Space_Grotesk'] text-xl font-bold text-white mb-4">
              External Subject Matter Experts
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-cyan-950/50 p-3">
                    <Users className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-white">Mr. Girish Kumar</CardTitle>
                    <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                      Founder at T Squared IOT Labs
                    </CardDescription>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-cyan-950/50 p-3">
                    <Users className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-white">Mr. Santosh Narayanan</CardTitle>
                    <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                      GPU Power Modeling Architect, Intel Corp.
                    </CardDescription>
                  </div>
                </CardContent>
              </Card>
            </div>

            <h3 className="font-['Space_Grotesk'] text-xl font-bold text-white mb-4">Industry Connect</h3>
            <div className="grid grid-cols-1 gap-6 mb-8">
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-cyan-950/50 p-3">
                    <Users className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-white">Mr. Swamynathan</CardTitle>
                    <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                      5G Architect, HP CMS
                    </CardDescription>
                  </div>
                </CardContent>
              </Card>
            </div>

            <h3 className="font-['Space_Grotesk'] text-xl font-bold text-white mb-4">SoCSE Members</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">Chandramouleeswaran Sankaran</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    Professor, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">chandramouleeswarans@rvu.edu.in</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">Dr. Vidya M J</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    Asst. Professor, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">vidyam@rvu.edu.in</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">Mydhili K Nair</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    B. Tech Head, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">headbtechcse@rvu.edu.in</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">CVSN Reddy</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    Associate Professor, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">cvsnreddy@rvu.edu.in</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">Veena S</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    Assistant Professor, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">veenas@rvu.edu.in</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800 shadow-lg">
                <CardContent className="p-6">
                  <CardTitle className="text-lg text-white">Rutuparna N</CardTitle>
                  <CardDescription className="font-['Outfit'] text-sm text-gray-400">
                    Assistant Professor, SoCSE, RVU
                  </CardDescription>
                  <p className="font-['Outfit'] text-sm text-cyan-400 mt-1">rutuparnan@rvu.edu.in</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Internships Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400">
                Opportunities
              </div>
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Internships
              </h2>
              <p className="font-['Outfit'] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Internships will be offered to interested students where focused problem definitions will be provided to
                them. Working on these problems will allow students to work on a part of a larger research problem, and
                equip them with technical and non-technical skills required in industry and academia.
              </p>
              <p className="font-['Outfit'] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                The Centre for Distributed Computing aims to have tie-ups with Industry and Hospitals in and around
                Bengaluru. Through these, we aim to provide summer internships to our undergraduate students in industry
                or within the center.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/join">
                  <Button className="font-['Outfit'] bg-cyan-600 text-white hover:bg-cyan-700">
                    Apply for Internship
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full h-[310px] rounded-xl overflow-hidden">
                <Image
                  alt="Students working on projects"
                  src="/images/lab-workspace.png"
                  fill
                  className="object-cover object-center"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Future Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400">
                Looking Ahead
              </div>
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Future Events Planned
              </h2>
              <p className="font-['Outfit'] max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our upcoming initiatives to foster learning and innovation.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 mt-8">
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Student Internships</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-gray-400">
                  The Centre for Distributed Computing aims to have tie-ups with Industry and Hospitals in and around
                  Bengaluru. Through these, we aim to provide summer internships to our undergraduate students in
                  industry or within the center.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white">Guest Lectures</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-['Outfit'] text-gray-400">
                  Industry Experts will deliver guest lectures to our undergraduate students & research scholars on
                  upcoming, relevant topics. A few topics have also been identified for immediate delivery.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-cyan-900/20 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-['Space_Grotesk'] text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Join Our Community
              </h2>
              <p className="font-['Outfit'] max-w-[600px] text-gray-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Become a part of RV University's most innovative tech community and build the future together.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/join">
                <Button className="font-['Outfit'] bg-cyan-600 text-white hover:bg-cyan-700">
                  Join the Club
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

