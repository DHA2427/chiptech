import Link from "next/link"
import { ArrowRight, Github } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProjectsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Our Projects
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-200 md:text-xl">
                Explore the innovative projects developed by ChipTech Club members, showcasing their skills and
                creativity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="featured" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="featured">Featured Projects</TabsTrigger>
                <TabsTrigger value="robotics">Robotics</TabsTrigger>
                <TabsTrigger value="iot">IoT</TabsTrigger>
                <TabsTrigger value="embedded">Embedded Systems</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="featured" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <img
                      alt="Smart Agriculture Robot"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Smart Agriculture Robot</CardTitle>
                    <CardDescription>
                      An autonomous robot designed to monitor soil conditions and assist in precision farming.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project uses sensors to collect data on soil moisture, temperature, and nutrient levels,
                      helping farmers optimize irrigation and fertilization. The robot can navigate through fields
                      autonomously using GPS and computer vision.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Robotics</div>
                      <div className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs text-green-800">IoT</div>
                      <div className="rounded-full bg-purple-100 px-2.5 py-0.5 text-xs text-purple-800">AI</div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href="/projects/smart-agriculture-robot">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                    <Link
                      href="https://github.com/chiptech-club/smart-agri-robot"
                      className="text-gray-500 hover:text-blue-600"
                    >
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Smart Home Automation System"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Smart Home Automation System</CardTitle>
                    <CardDescription>
                      A comprehensive IoT system for home automation with voice control and energy monitoring.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project integrates various sensors and actuators to control lighting, temperature, security,
                      and appliances in a home environment. It features voice control, mobile app integration, and
                      energy consumption analytics.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs text-green-800">IoT</div>
                      <div className="rounded-full bg-orange-100 px-2.5 py-0.5 text-xs text-orange-800">Embedded</div>
                      <div className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs text-blue-800">Cloud</div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href="/projects/smart-home-automation">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                    <Link
                      href="https://github.com/chiptech-club/smart-home"
                      className="text-gray-500 hover:text-blue-600"
                    >
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Gesture-Controlled Prosthetic Hand"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Gesture-Controlled Prosthetic Hand</CardTitle>
                    <CardDescription>
                      A low-cost prosthetic hand that can be controlled through muscle sensors and gesture recognition.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project aims to create affordable prosthetic solutions using EMG sensors to detect muscle
                      movements and translate them into hand gestures. The design uses 3D-printed components and
                      open-source electronics.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <div className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs text-red-800">Biomedical</div>
                      <div className="rounded-full bg-orange-100 px-2.5 py-0.5 text-xs text-orange-800">Embedded</div>
                      <div className="rounded-full bg-purple-100 px-2.5 py-0.5 text-xs text-purple-800">AI</div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href="/projects/prosthetic-hand">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                    <Link
                      href="https://github.com/chiptech-club/prosthetic-hand"
                      className="text-gray-500 hover:text-blue-600"
                    >
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="robotics" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <img
                      alt="Smart Agriculture Robot"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Smart Agriculture Robot</CardTitle>
                    <CardDescription>
                      An autonomous robot designed to monitor soil conditions and assist in precision farming.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project uses sensors to collect data on soil moisture, temperature, and nutrient levels,
                      helping farmers optimize irrigation and fertilization.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/smart-agriculture-robot" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Autonomous Delivery Robot"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Autonomous Delivery Robot</CardTitle>
                    <CardDescription>
                      A small-scale robot designed for last-mile delivery in campus environments.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This robot can navigate through pedestrian areas, avoid obstacles, and deliver small packages to
                      specific locations within the university campus.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/delivery-robot" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Swarm Robotics Platform"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Swarm Robotics Platform</CardTitle>
                    <CardDescription>
                      A platform for experimenting with multi-robot coordination and swarm intelligence.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project explores how multiple simple robots can work together to accomplish complex tasks
                      through local interactions and distributed control.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/swarm-robotics" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="iot" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <img
                      alt="Smart Home Automation System"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Smart Home Automation System</CardTitle>
                    <CardDescription>
                      A comprehensive IoT system for home automation with voice control and energy monitoring.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project integrates various sensors and actuators to control lighting, temperature, security,
                      and appliances in a home environment.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/smart-home-automation" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Air Quality Monitoring Network"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Air Quality Monitoring Network</CardTitle>
                    <CardDescription>
                      A distributed network of sensors for monitoring air quality across the university campus.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project uses low-cost sensors to measure particulate matter, CO2, temperature, and humidity,
                      providing real-time air quality data through a web dashboard.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/air-quality-monitoring" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Smart Water Management System"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Smart Water Management System</CardTitle>
                    <CardDescription>
                      An IoT solution for monitoring and optimizing water usage in buildings and gardens.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This system uses flow sensors, leak detectors, and smart valves to monitor water consumption,
                      detect leaks, and automate irrigation based on weather forecasts and soil moisture levels.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/water-management" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="embedded" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <img
                      alt="Gesture-Controlled Prosthetic Hand"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Gesture-Controlled Prosthetic Hand</CardTitle>
                    <CardDescription>
                      A low-cost prosthetic hand that can be controlled through muscle sensors and gesture recognition.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This project aims to create affordable prosthetic solutions using EMG sensors to detect muscle
                      movements and translate them into hand gestures.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/prosthetic-hand" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Wearable Health Monitor"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Wearable Health Monitor</CardTitle>
                    <CardDescription>
                      A compact wearable device for monitoring vital signs and physical activity.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This device tracks heart rate, body temperature, steps, and sleep patterns, providing insights
                      into health trends through a mobile app interface.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/health-monitor" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <img
                      alt="Solar-Powered Weather Station"
                      className="aspect-video w-full rounded-lg object-cover"
                      height="225"
                      src="/placeholder.svg?height=225&width=400"
                      width="400"
                    />
                    <CardTitle className="mt-4">Solar-Powered Weather Station</CardTitle>
                    <CardDescription>
                      An energy-efficient weather monitoring system powered by solar energy.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      This station collects data on temperature, humidity, pressure, rainfall, wind speed, and solar
                      radiation, operating autonomously with minimal maintenance.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Link href="/projects/weather-station" className="w-full">
                      <Button variant="outline" size="sm" className="w-full">
                        View Details
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Project Proposal Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-blue-100 px-3 py-1 text-sm text-blue-800">Have an Idea?</div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Propose a Project</h2>
              <p className="text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                ChipTech Club welcomes project proposals from members. If you have an innovative idea related to
                robotics, IoT, or embedded systems, we'd love to hear from you.
              </p>
              <p className="text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Approved projects receive mentorship, access to resources, and potential funding to bring your ideas to
                life.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/projects/propose">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Submit a Proposal
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <img
                alt="Students working on a project"
                className="aspect-video overflow-hidden rounded-xl object-cover object-center"
                height="310"
                src="/placeholder.svg?height=310&width=550"
                width="550"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Join Our Community</h2>
              <p className="max-w-[600px] text-gray-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Become a member of ChipTech Club and work on exciting projects with like-minded tech enthusiasts.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/join">
                <Button className="bg-white text-blue-700 hover:bg-gray-100">
                  Join the Club
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

