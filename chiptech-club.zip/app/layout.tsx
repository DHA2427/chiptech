import type React from "react"
import { Inter } from "next/font/google"
import Link from "next/link"
import Image from "next/image"
import { ChevronDown, Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ThemeProvider } from "@/components/theme-provider"

import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "ChipTech Club - RV University",
  description: "RV University's premier club for IoT, Edge Computing, and hardware innovations.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-gray-950 text-gray-100`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <div className="flex min-h-screen flex-col">
            <header className="sticky top-0 z-50 w-full border-b border-gray-800 bg-gray-950/95 backdrop-blur supports-[backdrop-filter]:bg-gray-950/60">
              <div className="container flex h-16 items-center justify-between">
                <div className="flex items-center gap-4">
                  <Link href="/" className="flex items-center gap-3">
                    <Image src="/images/logo.png" alt="ChipTech Logo" width={40} height={40} className="w-10 h-10" />
                    <span className="text-xl font-bold text-cyan-400 font-['Space_Grotesk']">ChipTech</span>
                  </Link>
                  <div className="h-6 w-px bg-gray-800"></div>
                  <Link href="https://www.rvu.edu.in" target="_blank" rel="noopener noreferrer">
                    <Image
                      src="/images/rv-university-logo.png"
                      alt="RV University Logo"
                      width={100}
                      height={40}
                      className="h-8 w-auto"
                    />
                  </Link>
                </div>
                <nav className="hidden md:flex gap-6">
                  <Link
                    href="/"
                    className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                  >
                    Home
                  </Link>
                  <Link
                    href="/about"
                    className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                  >
                    About
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="link"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 p-0 h-auto font-['Outfit']"
                      >
                        Activities
                        <ChevronDown className="ml-1 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-gray-900 border-gray-800">
                      <DropdownMenuItem
                        asChild
                        className="text-gray-300 hover:text-cyan-400 focus:text-cyan-400 focus:bg-gray-800 font-['Outfit']"
                      >
                        <Link href="/events">Events</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        asChild
                        className="text-gray-300 hover:text-cyan-400 focus:text-cyan-400 focus:bg-gray-800 font-['Outfit']"
                      >
                        <Link href="/workshops">Workshops</Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Link
                    href="/resources"
                    className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                  >
                    Resources
                  </Link>
                  <Link
                    href="/contact"
                    className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                  >
                    Contact
                  </Link>
                </nav>
                <div className="hidden md:flex gap-2">
                  <Link href="/join">
                    <Button className="bg-cyan-600 hover:bg-cyan-700 text-white font-['Outfit']">Join Now</Button>
                  </Link>
                </div>
                <Sheet>
                  <SheetTrigger asChild className="md:hidden">
                    <Button variant="outline" size="icon" className="border-gray-700">
                      <Menu className="h-5 w-5 text-gray-300" />
                      <span className="sr-only">Toggle menu</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="bg-gray-900 border-gray-800">
                    <div className="flex flex-col gap-6 mt-6">
                      <Link
                        href="/"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                      >
                        Home
                      </Link>
                      <Link
                        href="/about"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                      >
                        About
                      </Link>
                      <Link
                        href="/events"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                      >
                        Events
                      </Link>
                      <Link
                        href="/resources"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                      >
                        Resources
                      </Link>
                      <Link
                        href="/contact"
                        className="text-sm font-medium text-gray-300 hover:text-cyan-400 hover:underline underline-offset-4 font-['Outfit']"
                      >
                        Contact
                      </Link>
                      <Link href="/join">
                        <Button className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-['Outfit']">
                          Join Now
                        </Button>
                      </Link>
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t border-gray-800 py-6 md:py-8 bg-gray-950">
              <div className="container flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="text-center md:text-left">
                  <p className="text-sm text-gray-400">© 2025 ChipTech Club. All rights reserved.</p>
                </div>
                <div className="flex justify-center gap-4 md:justify-end">
                  <Link href="#" className="text-sm text-gray-400 hover:text-cyan-400 hover:underline">
                    Privacy Policy
                  </Link>
                  <Link href="#" className="text-sm text-gray-400 hover:text-cyan-400 hover:underline">
                    Terms of Service
                  </Link>
                  <Link href="#" className="text-sm text-gray-400 hover:text-cyan-400 hover:underline">
                    Contact
                  </Link>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'