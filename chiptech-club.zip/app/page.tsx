import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Calendar, ChevronRight, Code, Cpu, Layers, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-gray-900 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 to-transparent"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white font-['Space_Grotesk']">
                  ChipTech
                </h1>
                <p className="max-w-[600px] text-gray-300 md:text-xl font-['Outfit']">
                  Explore the world of IoT, Edge Computing, and hardware innovations with RV University's premier tech
                  community.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/join">
                  <Button className="bg-cyan-600 text-white hover:bg-cyan-700 font-['Outfit']">
                    Join Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/events">
                  <Button
                    variant="outline"
                    className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Upcoming Events
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full h-[310px] rounded-xl overflow-hidden">
                <Image
                  alt="CTRL+BUILD"
                  src="/images/ctrl-build.png"
                  fill
                  className="object-contain object-center"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400 font-['Outfit']">
                Upcoming Events
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Join Our Next Meetup
              </h2>
              <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                Participate in workshops, hackathons, and tech talks organized by ChipTech.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white font-['Space_Grotesk']">Ideathon</CardTitle>
                <CardDescription className="text-gray-400 font-['Outfit']">
                  Brainstorm innovative solutions for real-world IoT and Edge Computing challenges.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Calendar className="h-4 w-4 text-cyan-400" />
                  <span>
                    Status: <span className="text-cyan-400">Loading...</span>
                  </span>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Users className="h-4 w-4 text-cyan-400" />
                  <span>Tech Lab, Engineering Building</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/events/ideathon" className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Register Now
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white font-['Space_Grotesk']">Roboquest</CardTitle>
                <CardDescription className="text-gray-400 font-['Outfit']">
                  Robotics competition to build and program autonomous robots for specific challenges.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Calendar className="h-4 w-4 text-cyan-400" />
                  <span>
                    Status: <span className="text-cyan-400">Processing...</span>
                  </span>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Users className="h-4 w-4 text-cyan-400" />
                  <span>Innovation Center</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/events/roboquest" className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Register Now
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card className="bg-gray-900 border-gray-800 shadow-lg">
              <CardHeader>
                <CardTitle className="text-white font-['Space_Grotesk']">Circutrix</CardTitle>
                <CardDescription className="text-gray-400 font-['Outfit']">
                  Circuit design competition focusing on innovative embedded systems solutions.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Calendar className="h-4 w-4 text-cyan-400" />
                  <span>
                    Status: <span className="text-cyan-400">Deploying...</span>
                  </span>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-gray-400 font-['Outfit']">
                  <Users className="h-4 w-4 text-cyan-400" />
                  <span>Auditorium, Main Campus</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/events/circutrix" className="w-full">
                  <Button
                    variant="outline"
                    className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                  >
                    Register Now
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
          <div className="flex justify-center mt-8">
            <Link href="/events">
              <Button
                variant="outline"
                className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
              >
                View All Events
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Focus Areas Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Key Research Areas
              </h2>
              <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                The ChipTech explores various domains of IoT, Edge Computing, and hardware innovation.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8">
            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 bg-gray-900/50 p-6 shadow-lg">
              <div className="rounded-full bg-cyan-950/50 p-3">
                <Cpu className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">Edge Computing</h3>
              <p className="text-center text-gray-400 font-['Outfit']">
                Research on AI in Edge Computing, Edge resource management, and Distributed Computing.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 bg-gray-900/50 p-6 shadow-lg">
              <div className="rounded-full bg-cyan-950/50 p-3">
                <Layers className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">IoT Applications</h3>
              <p className="text-center text-gray-400 font-['Outfit']">
                Developing IoT solutions for Healthcare, Agriculture, and Industrial automation.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 bg-gray-900/50 p-6 shadow-lg">
              <div className="rounded-full bg-cyan-950/50 p-3">
                <Code className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">Assistive Technologies</h3>
              <p className="text-center text-gray-400 font-['Outfit']">
                Creating innovative solutions to assist people with disabilities through technology.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-950">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-cyan-950/50 px-3 py-1 text-sm text-cyan-400">
                Our Activities
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white">ChipTech in Action</h2>
              <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                A glimpse into our workshops, events, and projects.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/students-working-1.png"
                alt="Students working on a project"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/hardware-project.png"
                alt="Hardware project in progress"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/water-level-project.png"
                alt="Water level detector project"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/ribbon-cutting.png"
                alt="Inauguration ceremony"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/group-photo-1.png"
                alt="Club members group photo"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-lg">
              <Image
                src="/images/auditorium.png"
                alt="Club event in auditorium"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-cyan-900/20 to-gray-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
        <div className="container px-4 md:px-6 relative">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white font-['Space_Grotesk']">
                Ready to Join?
              </h2>
              <p className="max-w-[600px] text-gray-300 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-['Outfit']">
                Become a part of RV University's most innovative tech community and build the future together.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/join">
                <Button className="bg-cyan-600 text-white hover:bg-cyan-700 font-['Outfit']">
                  Join the Club
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button
                  variant="outline"
                  className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white font-['Outfit']"
                >
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

